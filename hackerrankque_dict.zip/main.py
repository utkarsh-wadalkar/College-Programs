user_dict = {}
while True:
    key = input("Enter a key: ")
    value = input("Enter a value")
    user_dict[key] = value

    another_pair = input("do you want more? (yes/no)")
    if another_pair != "yes":
        break

print(user_dict)