n=int(input("Enter a number: "))
m=n%2
# print(m)
if m!=0:
    print("Weird")
elif n>=2 and n<=5:
    print("Not Weird")
elif n>=6 and n<=20:
    print("Weird")
elif n>=20:
    print("Not Weird")